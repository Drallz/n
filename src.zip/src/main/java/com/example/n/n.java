package com.example.n;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.constraintlayout.widget.Constraints;

import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.BufferedSink;

import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class n extends AppCompatActivity {
    OkHttpClient client = new OkHttpClient();
    private TextView responseTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(l.VERTICAL);
        Button b = new Button(this);
        b.setText("Purple_Click");
        setContentView(l);
        l.addView(b);

        final TextView t = new TextView(this);
        t.setText("\n");
        // l.addView(t);


        OkHttpClient client = new OkHttpClient();
          b.setOnClickListener(new View.OnClickListener() {
          @Override
           public void onClick(View v) {

        post("https://lamp.ms.wits.ac.za/home/s2582127/cars.php", "", new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();

            }

            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseStr = response.body().string();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // t.setText(responseStr);
                            try {
                                JSONArray alls = new JSONArray(responseStr);
                                for (int i = 0; i < alls.length(); i++) {
                                    JSONObject all = alls.getJSONObject(i);
                                    LayoutInflater inflater = getLayoutInflater();
                                    ConstraintLayout layout = (ConstraintLayout) inflater.inflate(R.layout.all, null);
                                    TextView number = layout.findViewById(R.id.numberi);
                                    number.setText(all.getString("NUMBER"));

//                                    TextView brand = layout.findViewById(R.id.brandi);
//                                    brand.setText(all.getString("BRAND"));
//
//                                    TextView car_id = layout.findViewById(R.id.car_idi);
//                                    car_id.setText(all.getString("CAR_ID"));
//
//                                    TextView owner = layout.findViewById(R.id.owneri);
//                                    owner.setText(all.getString("OWNER"));
//
//                                    TextView age = layout.findViewById(R.id.ageii);
//                                    age.setText(all.getString("AGE"));

                                    l.addView(layout);
                                    //  l.addView(t);

                                           /* String car_id = all.getString("CAR_ID");
                                            String owner = all.getString("OWNER") ;
                                            String brand = all.getString("BRAND");
                                            String number = all.getString("NUMBER");
                                            String age = all.getString("AGE");*/
                                    //   output = output + brand + "{"+ "\n" + "[ID:" + car_id + ", " + "\n"+ "OWNER:" + owner + ", " + "\n" + "BRAND:" + brand + ", " + "\n" + "NUMBER:" + number + ", " + "\n" + "AGE:" + age + "]" + "\n" + "}"  + "," + "\n";
                                }
                                //t.setText(output);
                            } catch (JSONException e) {
                                e.printStackTrace();
                                throw new RuntimeException(e);
                                // }
                            }

                        }
                    });
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            t.setText("Aowa it doesnt work");
                        }
                    });

                }
            }
        });

           }
          });


    }



    public static final MediaType JSON = MediaType.parse("application/json; charse=utf-8");

    Call post(String url, String json, Callback callback) {
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()

                .url(url)

                .post(body)
                .build();

        Call call = client.newCall(request);
        call.enqueue(callback);
        return call;


    }
}